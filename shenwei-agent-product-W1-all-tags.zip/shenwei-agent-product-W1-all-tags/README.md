# shenwei-agent-product · W1 全部 tag

每个文件夹是参考实现某个 tag 的完整代码（git archive 导出，不含 .git 与 .env）。

| tag | 文件数 | 说明 |
|---|---|---|
| w1.0 | 4 | w1.0 进入 W1 时的起点：工程版需求三份文档（总 spec、需求与非功能、威胁清单）+ README |
| w1.2 | 7 | w1.2 规格写成：周 spec w01-agent-loop（八节、W1-AC-01–07、六个案例）+ 独立变体任务书 + 1.1 的人工判定量表 |
| w1.4 | 24 | w1.4 仓库骨架：总 spec 与周 spec、ADR-001、AGENTS.md/CLAUDE.md、CI 最小 |
| w1.5 | 32 | w1.5 契约类型与 Protocol、ScriptedModel、FakeERP、测试计划 T01–T15 |
| w1.6 | 63 | w1.6 绿：guardrails 参数校验进执行器；ERP 客户端区分 timeout / 504 / 非 JSON；契约测试 |
| w1.7 | 67 | w1.7 CLI chat：接真实模型与 ERP，--scripted 离线；主案例真实跑通 |
| w1.8 | 75 | w1.8 CLI：会话持久、--resume 新 Run 装历史、--show-request、replay 子命令；真实会话继续与回放跑通 |
| w1.9 | 98 | w1.9 Release：ADR-002、冒烟六条与判定、红绿证据、六张故障卡、Git 实验实录、控制方式对照、发布检查脚本、Release 说明、本地 PR 审查记录 |
| w1 | 98 | 合并 week/01：W1 从需求到 Agent Loop（见 docs/weeks/w01/reviews/PR-w1.md） |
| w1-fix1 | 98 | w1-fix1 测试里的假密钥不再匹配 sk- 模式（发布检查第 3 项拦下的） |
